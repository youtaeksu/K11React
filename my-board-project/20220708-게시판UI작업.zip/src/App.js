import React, { Component } from 'react';
import './App.css';

import Top from './components/Top';
import Left from './components/Left';
import Bottom from './components/Bottom';
import ListContents from './components/ListContents';
import ViewContents from './components/ViewContents';
import WriteContents from './components/WriteContents';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      mode : "list"
    };
  }
  render(){
    //컴포넌트를 저장할 변수 생성
    let contents ;
    //각 mode에 따라 해당 컴포넌트를 저장 후 렌더링
    if(this.state.mode === 'list'){
      contents = <ListContents 
        myChangeMode={(pmode)=>{
          this.setState({mode : pmode});
        }}
      ></ListContents>
    }
    else if(this.state.mode === 'write'){
      contents = <WriteContents
        myChangeMode={(pmode)=>{
          this.setState({mode : pmode});
        }}
      ></WriteContents>
    }
    else if(this.state.mode === 'view'){
      contents = <ViewContents
        myChangeMode={(pmode)=>{
          this.setState({mode : pmode});
        }}
      ></ViewContents>
    }


    return (
      <div className="container">
        <Top></Top>
        <div className="row">
            <Left></Left>
            {/* mode에 따라 각기 다른 컴포넌트가 렌더링된다. */}
            { contents }
        </div>
        <Bottom></Bottom>
    </div>  
    );
  }
}

export default App;
