import React, {Component} from 'react';

class Bottom extends Component{
    render(){
      return (
        <div className="row" id="lay_bottom">
            <p>BOTTOM</p>
        </div>
      );
    }
  }
  export default Bottom;