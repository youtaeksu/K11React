import React, {Component} from 'react';

class Left extends Component{
    render(){
      return (
        <div className="col-lg-2" id="lay_left">
            <p>LEFT</p>
        </div>
      );
    }
  }
  export default Left;