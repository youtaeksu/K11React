import React, {Component} from 'react';

class WriteContents extends Component {
    render(){
      return (
        <div class="col-lg-10" id="lay_contents">
            <h2>게시판글쓰기</h2>
            <form method="post" onSubmit={(e)=>{}}>
            <table className="table table-bordered">
            <tbody>
                <tr>
                    <th width="20%">아이디</th>
                    <td width="80%">
                        <input type="text" name="id" />
                    </td>
                </tr>
                <tr>
                    <th>제목</th>
                    <td>
                        <input type="text" name="title" ></input>
                    </td>
                </tr>
                <tr>
                    <th>내용</th>
                    <td height="100">
                        <textarea name="content"></textarea>
                    </td>
                </tr>
                <tr>
                    <td colSpan="4" align="center">                     
                        <button type="submit" onClick={(e)=>{}}>
                            작성완료
                        </button>
                        <button type="button" 
                            onClick={
                                (e)=>{
                                    e.preventDefault();
                                    this.props.myChangeMode('list');
                                }
                            }
                        >리스트</button>
                </td>
            </tr>  
        </tbody>                              
        </table>
        </form>
    </div>
      );
    }
  }
  export default WriteContents;


